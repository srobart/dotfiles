#!/bin/bash

killall conky

sleep 30 &
conky -c ~/.conky/Info2 &
sleep 1 &
conky -c ~/.conky/Current_process2 &
sleep 1 &
conky -c ~/.conky/Disk2 &
sleep 1 &
conky -c ~/.conky/Net2 &
exit 0
